package ch.retorte.intervalmusiccompositor.spi;

/**
 * @author nw
 */
public interface TaskFinishListener {

	public void onTaskFinished();
	
}

package ch.retorte.intervalmusiccompositor.spi;

/**
 * @author nw
 */
public interface ProgramControl {

  public void quit();

}

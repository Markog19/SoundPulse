package ch.retorte.intervalmusiccompositor.messagebus;

/**
 * @author nw
 */
public class ErrorMessage extends ConsoleMessage {

  public ErrorMessage(String message) {
    super(message);
  }
}

package ch.retorte.intervalmusiccompositor.messagebus;

/**
 * Item to be transported by the message bus.
 * 
 * @author nw
 */
public interface Message {
}

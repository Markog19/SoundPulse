package ch.retorte.intervalmusiccompositor.list;

/**
 * @author nw
 */
public enum CompositionMode {
  SIMPLE, ADVANCED
}

package ch.retorte.intervalmusiccompositor.list;

/**
 * @author nw
 */
public enum ListSortMode {
  SORT, SORT_REV, SHUFFLE, MANUAL
}

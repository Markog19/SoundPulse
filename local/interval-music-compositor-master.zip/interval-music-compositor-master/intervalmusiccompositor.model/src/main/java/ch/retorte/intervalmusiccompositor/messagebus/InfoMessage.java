package ch.retorte.intervalmusiccompositor.messagebus;

/**
 * @author nw
 */
public class InfoMessage extends ConsoleMessage {

  public InfoMessage(String message) {
    super(message);
  }

}

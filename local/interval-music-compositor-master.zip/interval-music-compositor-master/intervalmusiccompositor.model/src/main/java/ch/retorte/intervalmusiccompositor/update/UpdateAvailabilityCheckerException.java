package ch.retorte.intervalmusiccompositor.update;

/**
 * @author nw
 */
public class UpdateAvailabilityCheckerException extends RuntimeException {

  private static final long serialVersionUID = 1L;

}

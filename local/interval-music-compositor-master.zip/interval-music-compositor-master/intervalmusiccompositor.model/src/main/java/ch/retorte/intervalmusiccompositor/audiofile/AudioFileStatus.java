package ch.retorte.intervalmusiccompositor.audiofile;

/**
 * @author nw
 */
public enum AudioFileStatus {
  EMPTY, OK, IN_PROGRESS, ERROR, QUEUED
}

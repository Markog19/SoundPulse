package ch.retorte.intervalmusiccompositor.list;

/**
 * @author nw
 */
public enum AudioFileListType {
  MUSIC, BREAK
}
